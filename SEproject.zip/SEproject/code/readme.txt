First Put all the Tables from postgres.sql file to a Database.


After that open the command prompt and run the following commands;


   javac main.java

   javac Academic.java

   javac Faculty.java

   javac Student.java


   java main


Give the input according to the Demand of the Program.

